<?php
// Text
$_['text_information']  = 'Thông tin';
$_['text_service']      = 'Chăm sóc khách hàng';
$_['text_extra']        = 'Chức năng khác';
$_['text_contact']      = 'Liên hệ';
$_['text_return']       = 'Trả hàng';
$_['text_sitemap']      = 'Sơ đồ trang';
$_['text_manufacturer'] = 'Thương hiệu - hãng';
$_['text_voucher']      = 'Phiếu quà tặng';
$_['text_affiliate']    = 'Đại lý';
$_['text_special']      = 'Khuyến mãi';
$_['text_account']      = 'Tài khoản của tôi';
$_['text_order']        = 'Lịch sử đơn hàng';
$_['text_wishlist']     = 'Danh sách yêu thích';
$_['text_newsletter']   = 'Thư thông báo';
$_['text_powered']      = 'Bản quyền thuộc <a href="http://www.a-cart.online">A-cart.online</a><br /> %s &copy; %s';