<?php
// Text
$_['text_all'] = 'Thấy tất cả';