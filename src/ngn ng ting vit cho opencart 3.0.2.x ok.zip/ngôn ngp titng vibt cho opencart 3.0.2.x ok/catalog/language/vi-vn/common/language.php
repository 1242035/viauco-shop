<?php
// Text
$_['text_language'] = 'Ngôn ngữ';