<?php
// Heading
$_['heading_title']    = 'Theo dõi đại lý';

// Text
$_['text_account']     = 'Tài khoản';
$_['text_description'] = 'Để đảm bảo bạn được thanh toán cho giới thiệu mà bạn gửi cho chúng tôi, chúng tôi cần theo dõi giới thiệu bằng cách đặt mã theo dõi trong liên kết URL của chúng tôi. Bạn có thể sử dụng các công cụ dưới đây để tạo liên kết đến %s web site.';

// Entry
$_['entry_code']       = 'Mã theo dõi của bạn';
$_['entry_generator']  = 'phát hiện Theo dõi liên kết';
$_['entry_link']       = 'Theo dõi liên kết';

// Help
$_['help_generator']  = 'Nhập tên sản phẩm bạn muốn liên kết đến';