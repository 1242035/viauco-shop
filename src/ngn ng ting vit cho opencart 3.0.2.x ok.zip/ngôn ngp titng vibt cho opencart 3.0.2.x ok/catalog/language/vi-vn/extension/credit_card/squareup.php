<?php

$_['heading_title'] = 'Thẻ tín dụng vuông';

$_['text_account'] = 'Tài khoản';
$_['text_back'] = 'Trởi lại';
$_['text_delete'] = 'Xóa';
$_['text_no_cards'] = 'Không có thẻ lưu trữ trên cơ sở dữ liệu của chúng tôi.';
$_['text_card_ends_in'] = '%s Thẻ kết thúc bằng &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; %s';
$_['text_warning_card'] = 'Bạn có xác nhận bạn muốn loại bỏ thẻ này? Bạn có thể thêm lại vào lần thanh toán tiếp theo.';
$_['text_success_card_delete'] = 'Thành công! Thẻ này đã bị xóa.';