<?php
// Text
$_['text_captcha']  = 'Mã Captcha';

// Entry
$_['entry_captcha'] = 'Nhập mã vào hộp dưới đây';

// Error
$_['error_captcha'] = 'Mã xác minh không khớp với hình ảnh!';