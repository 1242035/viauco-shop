<?php
// Text
$_['text_subject']  = '%s - Mật khẩu mới';
$_['text_greeting'] = 'Yêu cầu mật khẩu mới được gửi từ %s.';
$_['text_change']   = 'Để đặt lại mật khẩu của bạn bấm vào liên kết bên dưới:';
$_['text_ip']       = 'IP được sử dụng để thực hiện yêu cầu này là:';