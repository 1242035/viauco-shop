<?php
// Text
$_['text_subject']       = '%s - Cập nhật trạng thái Đổi / Trả hàng mã số: %s';
$_['text_return_id']     = ' ID Đổi / Trả hàng số:';
$_['text_date_added']    = 'Ngày Đổi / Trả:';
$_['text_return_status'] = 'Trạng thái Đổi / Trả hàng được cập nhật như sau:';
$_['text_comment']       = 'Ý kiến khác về việc giải quyết Đổi / Trả hàng của bạn:';
$_['text_footer']        = 'Vui lòng trả lời email này nếu bạn có bất kỳ câu hỏi gì. Trân trọng cám ơn!';