<?php
// Text
$_['text_subject'] = '%s - Tài khoản của bạn đã bị từ chối!';
$_['text_welcome'] = 'Chào mừng và cảm ơn bạn đã đăng ký tại %s!';
$_['text_denied']  = 'Rất tiếc, yêu cầu của bạn đã bị từ chối. Để biết thêm thông tin, bạn có thể liên lạc với chủ cửa hàng ở đây:';
$_['text_thanks']  = 'Cảm Ơn,';
