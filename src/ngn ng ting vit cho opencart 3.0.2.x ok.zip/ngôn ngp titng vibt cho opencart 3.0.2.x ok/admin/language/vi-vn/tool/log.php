<?php
// Heading
$_['heading_title'] = 'Lịch sử lỗi';

// Text
$_['text_success']  = 'Thành công: Bạn đã xóa lịch sử lỗi!';
$_['text_list']        = 'Danh sách các lỗi';

// Error
$_['error_warning']    = 'Cảnh báo: tệp nhật ký lỗi của bạn %s là %s!';
$_['error_permission'] = 'Bạn không có quyền xóa log lỗi!';