<?php
// Text
$_['text_footer']  = '<a href="http://www.a-cart.online">Phiên bản tiếng việt thuộc bản quyền của a-cart.online</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.';
$_['text_version'] = 'Phiên bản %s';